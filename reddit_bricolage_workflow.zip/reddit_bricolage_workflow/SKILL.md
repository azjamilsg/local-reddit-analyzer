---
name: reddit-bricolage-snr
description: Analyze user-selected Reddit thread excerpts with a transparent communication-theory-inspired SNR heuristic and provenance-aware review.
---

# Reddit thread bricolage and SNR workflow

Use this workflow to reconstruct a creative/technical process from user-selected comments and separate relevant evidence from low-relevance discussion.

## Boundaries

- Do not make Reddit API requests in this workflow.
- Do not build or run an automated Reddit HTML scraper, evade login/access controls, or bypass anti-bot controls.
- Use Browser Use for user-guided navigation and review. The user manually selects excerpts and saves them to `data/thread.json`.
- Treat the original post, a commenter quoting/relaying the source, and a commenter describing their own setup as separate evidence sources.
- Never attribute an adjacent commenter's toolchain to the target video unless the creator/source confirms it.

## Workflow

1. Open one specific thread using Browser Use; do not crawl outside it.
2. Manually select comments and save them in `data/thread.json`, retaining permalinks and parent context.
3. Run `reddit_bricolage.build_report` to produce JSON, CSV, and Markdown outputs.
4. Interpret scores only as retrieval hints; retain all supplied excerpts.
5. Label statements as direct, relayed, personal experience, inference, linked-artifact claim, or audience reaction.
6. Separate observations, attributions, inferences, and unknowns.
7. For multi-reviewer analysis, run `reddit_bricolage.prepare_research`; assign the four packets against the same snapshot, then reconcile with `SYNTHESIS_GUIDE.md`.

## SNR method

Scores prioritize comments containing relevant tool/process terms and modestly boost provenance language and questions. The score is not Shannon channel SNR, truth probability, confidence, or quality. Explain the scoring method and preserve low-score evidence.

## Commands

```sh
python -m reddit_bricolage.build_report data/thread.json --out-dir output --weights config/snr_weights.json
python -m reddit_bricolage.prepare_research output/analyzed_thread.json --source-json data/thread.json --out-dir research_packets
PYTHONPATH=. python -m unittest discover -s tests -v
```
