# Project instructions

For Reddit research, follow `SKILL.md`. Do not call Reddit APIs or build/run Reddit HTML scrapers. Browser Use is for user-guided navigation; the user manually selects excerpts into `data/thread.json`. Keep primary-source claims separate from quoted claims and commenters' personal workflows. SNR labels are triage aids, not fact checks; retain all supplied excerpts in outputs.

Run offline tests with:

```sh
PYTHONPATH=. python -m unittest discover -s tests -v
```
