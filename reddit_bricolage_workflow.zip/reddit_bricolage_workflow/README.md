# Reddit Bricolage Workflow

Small local Python tools to analyze a user-prepared snapshot of one Reddit discussion, preserve comment context, and rank comments by workflow and provenance signal. There is no Reddit API client and no automated Reddit page extractor.

## Browser-assisted input

Use Browser Use to navigate to the specific thread. Manually choose the comments to include and save them in `data/thread.json`, using `data/thread.template.json` as a guide. Keep each comment's permalink and parent context so the analysis stays auditable.

Reddit's current Responsible Builder Policy applies to everyone using Reddit data and identifies restrictions on scraping and mining. This project therefore keeps Browser Use to user-guided navigation and review; it does not instruct an agent to automatically harvest the comment tree. For automated collection, obtain Reddit's authorization first.

Browser Use offers a CLI to give an existing agent such as Codex browser access and a Python library for local browser tasks. The project page currently lists Python 3.11+ for the library. Browser Use may still need a model-provider key depending on the configuration; the analysis scripts below run offline once you prepare the JSON.

References: [Browser Use setup](https://github.com/browser-use/browser-use) · [Reddit Responsible Builder Policy](https://support.reddithelp.com/hc/en-us/articles/42728983564564-Responsible-Builder-Policy)

## Install and run

Use Python 3.10+ for the local analysis scripts:

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -e .
```

Copy `data/thread.template.json` to `data/thread.json`, fill in the thread and selected comments, then run:

```sh
python -m reddit_bricolage.build_report data/thread.json --out-dir output --weights config/snr_weights.json
python -m reddit_bricolage.prepare_research output/analyzed_thread.json --source-json data/thread.json --out-dir research_packets
```

Outputs:

- `output/analyzed_thread.json` — supplied comments with transparent scores, labels, parent IDs, and flags
- `output/comments_ranked.csv` — reviewable comment table
- `output/thread_brief.md` — compact summary of high-ranked comments
- `research_packets/` — four focused reviewer packets and a synthesis guide

Low-scoring comments are retained. The heuristic surfaces terms such as Midjourney, Suno, Seedance, moodboard, prompt, orchestration, review, and rendering. It labels a commenter's personal workflow separately from a claim about the linked video. It cannot establish truth or creator intent; check each permalink and parent context.

## SNR model

The score is a qualitative retrieval priority, capped at 10. Tool and process terms add transparent weights; provenance language and questions add smaller weights. The score is not Shannon channel SNR, a probability, a fact-check, or an artistic quality score. Tune `config/snr_weights.json` for another question. The labels are for triage only:

- `high_signal_process_or_provenance`
- `contextual_signal`
- `low_signal_reaction`
- `low_signal_or_off_topic`

## Researcher workflow

The packet generator creates four assignments from the same saved snapshot: process reconstruction, provenance audit, audience reaction, and independent SNR review. Give them to Codex subagents or human reviewers; reconcile disagreements with `research_packets/SYNTHESIS_GUIDE.md`. Keep the linked video's production claims separate from commenters' personal toolchains.

## Codex CLI and Browser Use

From this folder, run `codex` and ask it to follow `AGENTS.md` and `SKILL.md`. Use Browser Use to open/navigate to the thread; manually select the excerpts; then run the offline Python commands. OpenAI documents Codex CLI MCP support, and Browser Use documents a CLI that can give Codex browser access. Neither changes Reddit's rules for automated data collection.

## Tests

```sh
PYTHONPATH=. python -m unittest discover -s tests -v
```

The tests are offline and do not access Reddit.
