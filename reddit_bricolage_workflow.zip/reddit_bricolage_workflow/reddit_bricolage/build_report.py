"""Analyze a saved thread JSON file and write auditable JSON, CSV, and Markdown."""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
from typing import Any
from .snr import score_comment


def analyze(data: dict[str, Any], weights: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    comments = data.get("comments", [])
    result = [score_comment(c, weights=weights) for c in comments]
    return sorted(result, key=lambda x: (x["snr_score"], x.get("score") or 0), reverse=True)


def write_outputs(data: dict[str, Any], out_dir: Path, weights: dict[str, Any] | None = None) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    ranked = analyze(data, weights=weights)
    (out_dir / "analyzed_thread.json").write_text(json.dumps({
        "schema_version": 1,
        "source_url": data.get("source_url"),
        "retrieved_at": data.get("retrieved_at"),
        "submission": data.get("submission", {}),
        "comments": ranked,
        "method": "qualitative keyword retrieval heuristic; scores are not truth or quality scores",
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    fields = ["id", "parent_id", "author", "score", "depth", "snr_score", "snr_label", "scope_label", "matched_tools", "matched_process_terms", "matched_provenance_terms", "evidence_flags", "body", "permalink"]
    with (out_dir / "comments_ranked.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in ranked:
            row = dict(row)
            for k in ("matched_tools", "matched_process_terms", "matched_provenance_terms", "evidence_flags"):
                row[k] = "; ".join(row.get(k, []))
            writer.writerow(row)
    sub = data.get("submission", {})
    lines = [f"# Reddit thread analysis: {sub.get('title', 'Untitled')}", "", f"Source: {data.get('source_url', 'not recorded')}", "", f"Comments analyzed: {len(ranked)}", "", "## Highest workflow and provenance signal", ""]
    selected = [r for r in ranked if r["snr_score"] >= 1.5][:30]
    if not selected:
        lines.append("No comments passed the current threshold.")
    for r in selected:
        body = " ".join(str(r.get("body", "")).split())
        lines.extend([
            f"### Score {r['snr_score']} · {r['snr_label']} · {r['scope_label']}",
            f"- Comment: {r.get('permalink') or r.get('id') or 'no permalink'}",
            f"- Matched terms: {', '.join(r['matched_tools'] + r['matched_process_terms']) or 'none'}",
            f"- Evidence flags: {', '.join(r['evidence_flags']) or 'none'}",
            f"> {body}", "",
        ])
    lines.extend(["## Method and limits", "", "The score ranks comments for review using transparent tool and process keywords. It does not verify claims, infer creator intent, or measure an engineering SNR. Low-scoring comments remain in the JSON and CSV. Read each comment with its parent context and check claims against the creator or another primary source.", ""])
    (out_dir / "thread_brief.md").write_text("\n".join(lines), encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input", type=Path, help="JSON matching data/thread.template.json")
    ap.add_argument("--out-dir", type=Path, default=Path("output"))
    ap.add_argument("--weights", type=Path, help="Optional JSON file with tool_terms, process_terms, provenance_weight, question_weight, and max_score")
    args = ap.parse_args(argv)
    data = json.loads(args.input.read_text(encoding="utf-8"))
    weights = json.loads(args.weights.read_text(encoding="utf-8")) if args.weights else None
    write_outputs(data, args.out_dir, weights=weights)
    print(f"Wrote analysis files to {args.out_dir}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
