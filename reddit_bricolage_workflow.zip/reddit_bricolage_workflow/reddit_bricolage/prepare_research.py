"""Create focused, source-grounded researcher packets from an analyzed thread.

No model calls or web access are made here. Packets can be assigned to Codex
subagents or human reviewers; all reviewers work from the same saved JSON.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


ROLES = {
    "process_researcher": (
        "Reconstruct the reported creative workflow. Extract concrete stages, tools, "
        "inputs/outputs, and iteration tactics. Keep the linked video's process "
        "separate from commenters' own workflows. Do not fill gaps with assumptions."
    ),
    "provenance_auditor": (
        "Audit who is making each claim and how they know it. Separate direct post "
        "claims, quoted/relayed source claims, personal experience, and inference. "
        "Flag unsupported attribution and identify what primary source would verify it."
    ),
    "audience_analyst": (
        "Summarize audience questions, reactions, disagreements, and competing "
        "interpretations. Use reactions as evidence of reception, not evidence of "
        "the video's production process. Preserve meaningful counterexamples."
    ),
    "snr_verifier": (
        "Independently challenge the SNR ranking and proposed workflow. Find high-value "
        "comments the heuristic may have missed, low-value hits it over-ranked, and "
        "claims that must stay uncertain. Recommend a concise synthesis with confidence."
    ),
}


def _comment_context(comment: dict[str, Any], by_id: dict[str, dict[str, Any]]) -> str:
    explicit = " ".join(str(comment.get("parent_context", "")).split())
    if explicit:
        return explicit[:700] + ("..." if len(explicit) > 700 else "")
    parent_id = str(comment.get("parent_id", ""))
    parent = by_id.get(parent_id.rsplit("_", 1)[-1])
    if parent is None:
        return ""
    body = " ".join(str(parent.get("body", "")).split())
    if len(body) > 700:
        body = body[:697] + "..."
    return body


def create_packets(data: dict[str, Any], analyzed: list[dict[str, Any]]) -> dict[str, str]:
    """Render one consistent evidence set into four role-specific prompt files."""
    by_id = {str(c.get("id")): c for c in data.get("comments", []) if c.get("id")}
    source = data.get("source_url") or "not recorded"
    title = data.get("submission", {}).get("title", "Untitled Reddit thread")
    header = (
        f"# Shared evidence\n\nThread: {title}\n\nSource: {source}\n\n"
        "Use only the evidence below for thread-derived claims. The SNR score is a "
        "keyword-based review priority, not truth, quality, or confidence. Commenters' "
        "personal workflows are not proof of the linked video's workflow. Cite comment "
        "permalinks for each material assertion. Do not expose or infer usernames.\n\n"
        "## Comments\n"
    )
    comment_lines = []
    for c in analyzed:
        body = " ".join(str(c.get("body", "")).split())
        parent = _comment_context(c, by_id)
        comment_lines.extend([
            f"### {c.get('id', 'unknown')} · SNR {c.get('snr_score', 0)} · "
            f"{c.get('scope_label', 'unclassified')} · Reddit score {c.get('score', 0)}",
            f"Permalink: {c.get('permalink') or 'not recorded'}",
            f"Parent context: {parent or '[top-level or parent not included]'}",
            f"Comment text: {body or '[empty]'}",
            "",
        ])
    shared = header + "\n".join(comment_lines)
    packets = {}
    for role, instruction in ROLES.items():
        packets[role + ".md"] = (
            f"# Research packet: {role.replace('_', ' ').title()}\n\n"
            f"## Assignment\n\n{instruction}\n\n"
            "## Required output\n\n"
            "Return: (1) up to five evidence-backed findings, each with a permalink; "
            "(2) direct/relayed/personal/inference classification; (3) unresolved "
            "questions; and (4) confidence marked high, medium, or low with a short "
            "reason. Do not present the SNR score as confidence.\n\n---\n\n"
            + shared
        )
    return packets


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("analyzed_json", type=Path, help="analyzed_thread.json output")
    parser.add_argument("--source-json", type=Path, help="raw fetched thread JSON for parent context")
    parser.add_argument("--out-dir", type=Path, default=Path("research_packets"))
    args = parser.parse_args(argv)
    analyzed_data = json.loads(args.analyzed_json.read_text(encoding="utf-8"))
    source_path = args.source_json
    if source_path is None:
        source_path = args.analyzed_json
    source_data = json.loads(source_path.read_text(encoding="utf-8"))
    packets = create_packets(source_data, analyzed_data.get("comments", []))
    args.out_dir.mkdir(parents=True, exist_ok=True)
    for name, text in packets.items():
        (args.out_dir / name).write_text(text, encoding="utf-8")
    (args.out_dir / "SYNTHESIS_GUIDE.md").write_text(SYNTHESIS_GUIDE, encoding="utf-8")
    print(f"Wrote {len(packets)} researcher packets and a synthesis guide to {args.out_dir}")
    return 0


SYNTHESIS_GUIDE = """# Research synthesis guide

## Run the review

1. Give each role packet to a separate researcher or reviewer. Every packet is built from the same fetched thread snapshot; do not let roles fetch different versions.
2. Ask each reviewer to return concise findings with comment permalinks and evidence labels.
3. Compare overlap and disagreements. A synthesis lead checks every cited comment in its parent context and records what remains unknown.
4. Build the final workflow only from claims that actually describe the linked artifact. Put commenter personal workflows in a separate section.

## Claim ledger

| Claim | Speaker/source | Evidence class | Permalink | Confidence | Open check |
|---|---|---|---|---|---|
| | | Direct / relayed / personal / inference | | High / medium / low | |

## Reconciliation rules

- Prefer direct creator/source evidence over recollection or inference.
- Keep a disagreement if the thread does not resolve it; do not average conflicting claims into certainty.
- Treat tool names as mentions, not proof that a tool produced a specific asset.
- Use audience reactions to describe reception only.
- Use SNR solely to prioritize review. Check low-ranked comments for missed evidence.
- Preserve the original JSON and link all reported claims to a comment permalink.
"""


if __name__ == "__main__":
    raise SystemExit(main())
