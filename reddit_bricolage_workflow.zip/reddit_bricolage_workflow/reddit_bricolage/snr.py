"""Transparent, qualitative signal-to-noise scoring for Reddit comments.

Scores prioritize comments that help reconstruct process or assess provenance.
They do not determine truth, quality, or creator intent. Nothing is deleted.
"""
from __future__ import annotations
import re
from typing import Any

TOOL_TERMS = {
    "midjourney": 2.0, "seedance": 2.0, "suno": 2.0, "orca": 2.0,
    "orca ade": 2.0, "opus": 1.2, "claude code": 1.2, "api key": 1.6,
    "hyperframes": 1.6, "gsap": 1.2, "ffmpeg": 1.2, "numpy": 1.0,
    "elevenlabs": 1.2, "whisper": 1.0, "parakeet": 1.0,
}
PROCESS_TERMS = {
    "prompt": 1.6, "moodboard": 1.6, "storyboard": 1.8, "orchestrat": 2.0,
    "subagent": 1.8, "worker": 1.0, "review": 1.0, "editor": 1.0,
    "render": 1.1, "iteration": 1.4, "follow-up": 1.2, "followup": 1.2,
    "contact sheet": 1.4, "workflow": 1.5, "pipeline": 1.2, "continuity": 1.1,
    "human": 0.8, "created on its own": 1.6, "by itself": 1.3,
}
PROVENANCE_TERMS = ("source", "from op", "op source", "my setup", "my projects", "i use", "i usually", "i've been", "according to")
QUESTION_TERMS = ("?", "what did", "how did", "what tools", "what was the prompt")
PRAISE_TERMS = ("amazing", "sick", "fire", "dope", "insane", "awesome", "great", "impressive", "catchy")


def _contains(text: str, phrase: str) -> bool:
    if phrase in {"orchestrat"}:
        return re.search(r"orchestrat\w*", text) is not None
    return phrase in text


def classify_scope(text: str) -> str:
    low = text.casefold()
    if any(x in low for x in ("my setup", "my projects", "i usually", "i've been doing", "my workflow", "i use")):
        return "commenter_personal_workflow"
    if any(x in low for x in ("from op", "op source", "source says", "the source")):
        return "relayed_source_claim"
    if any(x in low for x in ("created this on its own", "by itself", "this video", "the video")):
        return "claim_about_linked_video"
    if len(low.split()) <= 12 and any(w in low for w in PRAISE_TERMS):
        return "audience_reaction"
    return "general_comment"


def score_comment(comment: dict[str, Any], weights: dict[str, Any] | None = None) -> dict[str, Any]:
    weights = weights or {}
    tool_terms = weights.get("tool_terms", TOOL_TERMS)
    process_terms = weights.get("process_terms", PROCESS_TERMS)
    provenance_weight = float(weights.get("provenance_weight", 0.7))
    question_weight = float(weights.get("question_weight", 0.7))
    max_score = float(weights.get("max_score", 10.0))
    body = str(comment.get("body", ""))
    low = body.casefold()
    tool_hits = [term for term in tool_terms if _contains(low, term)]
    process_hits = [term for term in process_terms if _contains(low, term)]
    provenance_hits = [term for term in PROVENANCE_TERMS if term in low]
    question_hits = [term for term in QUESTION_TERMS if term in low]
    raw = sum(float(tool_terms[x]) for x in tool_hits) + sum(float(process_terms[x]) for x in process_hits)
    raw += min(2.0, provenance_weight * len(provenance_hits)) + (question_weight if question_hits else 0.0)
    # Keep the scale bounded and understandable; this is a retrieval heuristic.
    score = min(max_score, round(raw, 1))
    scope = classify_scope(body)
    if scope == "audience_reaction" and score < 2:
        label = "low_signal_reaction"
    elif score >= 4:
        label = "high_signal_process_or_provenance"
    elif score >= 1.5:
        label = "contextual_signal"
    else:
        label = "low_signal_or_off_topic"
    flags = []
    if scope == "commenter_personal_workflow":
        flags.append("personal_workflow_not_video_proof")
    if scope == "relayed_source_claim":
        flags.append("secondhand_attribution")
    if scope == "claim_about_linked_video":
        flags.append("verify_against_creator_source")
    if scope == "audience_reaction":
        flags.append("reaction_not_fact_check")
    if not tool_hits and not process_hits:
        flags.append("no_workflow_terms_detected")
    return {
        **comment,
        "snr_score": score,
        "snr_label": label,
        "scope_label": scope,
        "matched_tools": tool_hits,
        "matched_process_terms": process_hits,
        "matched_provenance_terms": provenance_hits,
        "evidence_flags": flags,
    }
