import unittest
from reddit_bricolage.snr import score_comment, classify_scope

class SNRTests(unittest.TestCase):
    def test_toolchain_comment_ranks_as_high_signal(self):
        result = score_comment({"body": "Use Midjourney for images, Suno for music, and a moodboard."})
        self.assertGreaterEqual(result["snr_score"], 4)
        self.assertIn("midjourney", result["matched_tools"])
        self.assertIn("suno", result["matched_tools"])

    def test_personal_workflow_is_not_mislabeled_as_video_proof(self):
        text = "In my projects I use Orca ADE with reviewer and editor subagents."
        result = score_comment({"body": text})
        self.assertEqual(result["scope_label"], "commenter_personal_workflow")
        self.assertIn("personal_workflow_not_video_proof", result["evidence_flags"])

    def test_source_relay_is_secondhand(self):
        result = score_comment({"body": "From OP source: prompt, Midjourney, and moodboard."})
        self.assertEqual(result["scope_label"], "relayed_source_claim")
        self.assertIn("secondhand_attribution", result["evidence_flags"])

    def test_short_praise_is_retained_as_low_signal_reaction(self):
        result = score_comment({"body": "That was amazing."})
        self.assertEqual(result["snr_label"], "low_signal_reaction")
        self.assertEqual(result["scope_label"], "audience_reaction")

    def test_low_signal_comment_is_still_preserved(self):
        original = {"id": "abc", "body": "hello"}
        result = score_comment(original)
        self.assertEqual(result["id"], "abc")
        self.assertEqual(result["body"], "hello")

if __name__ == "__main__":
    unittest.main()
