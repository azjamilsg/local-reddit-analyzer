import unittest

from reddit_bricolage.prepare_research import create_packets


class ResearchPacketTests(unittest.TestCase):
    def test_all_roles_share_same_comment_and_parent_context(self):
        source = {
            "source_url": "https://reddit.com/thread",
            "submission": {"title": "Example"},
            "comments": [{"id": "a", "body": "Parent statement", "parent_id": "t3_x"}],
        }
        analyzed = [{
            "id": "b", "body": "I use Suno in my projects", "parent_id": "t1_a",
            "permalink": "https://reddit.com/comment/b", "snr_score": 2.7,
            "scope_label": "commenter_personal_workflow", "score": None,
        }]
        packets = create_packets(source, analyzed)
        self.assertEqual(len(packets), 4)
        for packet in packets.values():
            self.assertIn("Parent context: Parent statement", packet)
            self.assertIn("https://reddit.com/comment/b", packet)
            self.assertIn("I use Suno in my projects", packet)
        self.assertIn("personal workflows are not proof", packets["process_researcher.md"])


if __name__ == "__main__":
    unittest.main()
